import { Component } from '@angular/core';
import { LoginService } from './services/login.service';
import { FormBuilder,FormControl, FormGroup } from '@angular/forms';
import { EmployeeService } from './services/employee.service';
import { PolicyService } from './services/policy.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'frontend';


  public loginform!:FormGroup;
    public SalaryCal!:FormGroup;
    public Policyform!:FormGroup;
  constructor(private LoginUser:LoginService,private FormBuilder:FormBuilder,private EmployeeUser:EmployeeService,private PolicyUser:PolicyService){};
   
  ngOnInit(){
      this.loginform=this.FormBuilder.group({
         username:[''],
         password:['']
      })
      this.SalaryCal=this.FormBuilder.group( {
           Basic:[''],
           HRA:[''],
           DA:[''],
           IT:[''],
           PF:['']
        }
      )
      this.Policyform=this.FormBuilder.group( {
        PolicyNumber:[''],
        PolicyHoldersName:[''],
        PolicyAmt:[''],
        MaturityAmount:[''],
        Nominee:['']
     }
   )
  }

  username="";
  password="";
  loginUser(){
     this.LoginUser.validUser(this.loginform.value).subscribe
     (
       (data)=>
       {
         alert(data);
         console.log(JSON.stringify(data));
       },
       (error)=> console.log("Something went wrong!!!")
     );
    }
   arrEmployee:any=[];
   getAllEmployeeData(){
     this.EmployeeUser.getAllEmployeeData1().subscribe(
        (data)=>{
            console.log("Employee data recieved.");
            this.arrEmployee=data;
        },
        (error)=>console.log("Something went wrong")
      
      ) 
   }
   total_salary:any;
  calSalary(){
    this.EmployeeUser.calSalary1(this.SalaryCal.value).subscribe(
      (data)=>{
           console.log("Data recieved Successfully");
           this.total_salary=data;
           alert("Total Calculated Salary is :-"+data);
      },
      (error)=> console.log("Something went wrong!!!")
    )
  }
  empid=0;
  getEmployeeId(){
    this.EmployeeUser.getAllEmployeeDataById(this.empid).subscribe
    (
      (data)=>
      {
        alert("Id is "+data.id+" Name is "+data.name+" Department is "+data.dept+" Designation is" +data.designation);
        console.log("Employee data is  :"+JSON.stringify(data));

      },
      (error)=>console.log("Something went wrong!!!")
    );
  }
  names="";
  getEmployeeName(){
    this.EmployeeUser.getAllEmployeeDataByName(this.names).subscribe
    (
      (data)=>
      {
        alert("Id : "+data.id+" Name : "+data.name+" Department : "+data.dept+" Designation :" +data.designation);
        console.log("Employee data is : "+JSON.stringify(data));

      },
      (error)=>console.log("Something went wrong!!")
    );
  }
  insertEmployee()
  {
    let empObj={"id":105,"name":"Jyotsana","dept":"CSE","designation":"Fullstack Developer"};
    this.EmployeeUser.insertEmployee(empObj).subscribe(
      (data)=>{
        alert(data);
        console.log("New Record inserted : "+ JSON.stringify(data));
      },
      (error)=> console.log("Oops! we cannot insert your new record because : "+error)
    );
  } 
  updateEmployee(){
    let empObj={"id":104,"name":"Ranjana","dept":"ECE","designation":"Marketing"};
    this.EmployeeUser.updateEmployee(empObj).subscribe(
      (data)=>{
        alert("The Employee record is updated");
        
      },
      (error)=>console.log("Oops! Sorry, but we are unable to update your record.")
      );
  }
  empid1=0;
  deleteEmployee()
  {
    this.EmployeeUser.deleteEmployee(this.empid1).subscribe
    (
      (data)=>{
        console.log("The data which is being deleted is : "+JSON.stringify(data));
        alert(data);
      },
      (error)=> console.log('Sorry! We cannot delete the record because of the error : '+JSON.stringify(error))
  
    )
  }
  arrPolicy:any=[];
  getAllPolicyData(){
    this.PolicyUser.getAllPolicyData().subscribe(
       (data)=>{

           this.arrPolicy=data;
           alert("All policy data Recieved");
       },
       (error)=>console.log("Oops! Something went wrong.")
     
     ) 
  }
  policyId=0;
  getPolicyById(){
    this.PolicyUser.getAllPolicyDataById(this.policyId).subscribe
    (
      (data)=>
      {
        alert("Policy Id is "+data.id+" Policy Holder Name  is "+data.name+" Department is "+data.dept+" Designation is" +data.designation);
        console.log("Policy Data Details  :"+JSON.stringify(data));

      },
      (error)=>console.log("Something went wrong. Try again after sometime.")
    );
  }
  insertPolicy()
  {
    let PolicyObj={"PolicyNumber":112,"PolicyHoldersName":"Sameer Sharma","PolicyAmt":2000,"MaturityAmount":987,"Nominee":"Arnab"};
    this.PolicyUser.insertPolicy(PolicyObj).subscribe(
      (data)=>{
        alert(data);
        console.log("New Policy is being added :  "+ JSON.stringify(data));
      },
      (error)=> console.log("Sorry! We are unable to insert the record because : "+error)
    );
  }
  updatePolicy(){
    let PolicyObj={"PolicyNumber":146,"PolicyHoldersName":"Rakul","PolicyAmt":1800,"MaturityAmount":223,"Nominee":"Sonali"};
    this.PolicyUser.updatePolicyData(PolicyObj).subscribe(
      (data)=>{
        alert("Policy Data is updated");
        
      },
      (error)=>console.log("Sorry! Unable to update the data.")
      );
  }
  policyId1=0;
  deletePolicy()
  {
    this.PolicyUser.deletePolicy(this.policyId1).subscribe
    (
      (data)=>{
        console.log("The deleted policy is : "+JSON.stringify(data));
        alert(data);
      },
      (error)=> console.log('Sorry ! We are unable to delete the policy : '+JSON.stringify(error))
  
    )
  }
}



