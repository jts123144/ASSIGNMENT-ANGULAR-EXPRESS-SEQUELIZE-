var express =require("express")
var cors=require('cors');
const { json } = require("sequelize/dist");

var app= express();
app.use(cors());
app.use(express.json());
app.post ("/login",function(req,res){
    console.log("Logging at express side");
    var username=req.body.username;
    var password =req.body.password;
    console.log(`Given Data is uid: ${username} pwd: ${password}`);

      if(username=="jyotsana" &&  password=="admin")
        res.send({"username":"jyotsana","password":"admin"});
    res.send("You have entered wrong credentials");

})
app.listen(8000,function(){
    console.log("Server is running")
})
  