
const express= require('express')
const app=express();
app.use(express.json());
var cors=require('cors');
app.use(cors());
app.post('/totalsalary',(req,res)=>{
  var Basic=req.body.Basic;
  var HRA=req.body.HRA;
  var DA=req.body.DA;
  var IT=req.body.IT;
  var PF=req.body.PF;
  
  var total_salary = Basic + HRA + DA - (IT + PF);
  console.log("Your Total salary is "+total_salary);
  res.send(total_salary.toString());
})
app.listen(8002,function(){
    console.log("Server is running");
})