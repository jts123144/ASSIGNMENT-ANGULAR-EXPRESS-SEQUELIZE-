var express =require("express")


var app= express();
app.get ("/login",function(req,res){
    
    console.log("Logging at express running");
    var username=req.query.username;
    var pwd =req.query.password;
    
    console.log(`Given Data is uid: ${username} pwd: ${pwd}`);

      if(username=="jyotsana" &&  pwd=="admin")
        res.send("Your credentials are valid"); 
      res.send("Your credentials are invalid");

})
app.listen(8000,function(){
    console.log("Server is running")
})