var express = require("express");
var Sequelize = require("sequelize");
var dbConfig = require("./db.config");
var cors = require("cors");

const app = express();
app.use(express.json());
app.use(cors());

//Connect to the db
const sequelize = new Sequelize(dbConfig.DB,dbConfig.USER,dbConfig.PASSWORD,{
    host:dbConfig.HOST,
    dialect:dbConfig.dialect,
    pool:{
        max:dbConfig.pool.max,
        min:dbConfig.pool.min,
        acquire:dbConfig.pool.acquire,
        idle:dbConfig.pool.idle
    }
});

sequelize.authenticate().then( ()=>{
    console.log("Connected to database successfully...");
}).catch(err => {
    console.error("Unable to connect to db, because" + err);
})

//Define the structure of Users table
let userTable = sequelize.define("Users",{
    email:{
        primaryKey:true,
        type:Sequelize.STRING
    },
    uname:Sequelize.STRING,
    // phoneNo:Sequelize.INTEGER,
    pwd:Sequelize.STRING
},{
    timestamps:false,
    freezeTableName:true
});

userTable.sync({force:true}).then(()=>{
    console.log("Table created successfully")
}).catch (err => {
    console.error("Error is : "+err);
});

app.get("/",function(req,res){
    console.log("At GET of http://localhost:8002");
    res.send("Hello");
})

//Displays data of all Users
app.get("/getAllUsers",function(req,res){
    userTable.findAll({raw:true}).then(data=>{
        console.log(data);
        res.status(200).send(data);
    }).catch(err=>{
        console.error("There is an error getting data from db: " + err);
        res.status(400).send(err);
    })
})

//Display User based on email
app.get('/getUserByEmail/:email',function(req,res){
    var email=req.params.email;
    console.log("Given email: "+email)
    userTable.findByPk(email,{raw:true}).then(data=>{
        console.log(data);
        res.status(200).send(data)
    }).catch(err=>{
        console.error("There is an error getting data from db: "+err );
        res.status(400).send(err);
    })
})

//Add new user data
app.post('/addUser',function(req,res){
    var email=req.body.email;
    var uname =req.body.uname;
    // var phoneNo=req.body.phoneNo;
    var pwd=req.body.pwd;
    var userObj=userTable.build({email:email,uname:uname,pwd:pwd});
    userObj.save().then(data=>{
        var Msg="Record Inserted Successfully";
        res.status(201).send(data)
    }).catch(err=>{
        console.error("There is an error getting data from db: "+err );
        res.status(400).send(err);
    })
})

//Delete user data
app.delete('/deleteUserByEmail/:email',function(req,res){
    var email=req.params.email;
    userTable.destroy({where:{email:email}})
    .then(data=>{
        console.log(data)
        var Msg="Record Deleted Successfully";
        res.status(200).send(Msg)
    }).catch(err=>{
            console.error("There is an error getting data from db: "+err );
            res.status(400).send(err);
    })
})

app.listen(8002,function(){
    console.log("Server is listening at http://localhost:8002");
})